import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CouponService} from './coupon.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CouponsComponent } from './coupons/coupons.component';
import { HttpClient } from '../../node_modules/@types/selenium-webdriver/http';

@NgModule({
  declarations: [
    AppComponent,
    CouponsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [CouponService],
  bootstrap: [AppComponent]
})
export class AppModule { }
