import { Injectable } from '@angular/core';
import { Coupon } from './coupon';
import {HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class CouponService {
  coupons:Coupon[];

  constructor(private http:HttpClient) { 
    this.populateCoupons().subscribe(data=>this.coupons=data,error=>console.log(error))
  }
  populateCoupons():Observable<Coupon[]>{
    return this.http.get<Coupon[]>("http://localhost:6500/coupons")
  }

  getCoupons():Coupon[]{
    return this.coupons;
  }
}
