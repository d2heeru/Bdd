export interface Coupon{
    couponId:number,
    couponCode:string,
    discount:number,
    imageUrl:string
}