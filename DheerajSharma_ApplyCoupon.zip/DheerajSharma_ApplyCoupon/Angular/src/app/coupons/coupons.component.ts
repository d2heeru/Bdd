import { Component, OnInit } from '@angular/core';
import { Coupon } from '../coupon';
import { CouponService } from '../coupon.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.css']
})
export class CouponsComponent implements OnInit {

  coupons: Coupon[];
  flag: boolean = false;

  form = new FormGroup({
    couponCode:new FormControl('',[Validators.required, Validators.minLength(6)])
  })

  constructor(private couponService: CouponService) {
    this.populateCoupons();
  }

  populateCoupons() {
    this.couponService.populateCoupons().subscribe(data => this.coupons, error => console.error());
    this.coupons=this.couponService.getCoupons();
    this.flag = true
  }


  ngOnInit() {
  }

  showmessage(discount: string){
    alert(discount + " "+"Coupon Applied");
  }

}
