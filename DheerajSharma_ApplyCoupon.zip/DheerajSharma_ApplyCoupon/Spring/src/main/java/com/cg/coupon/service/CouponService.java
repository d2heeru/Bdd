package com.cg.coupon.service;

import java.util.List;

import com.cg.coupon.bean.Coupons;
import com.cg.coupon.exception.CouponException;

public interface CouponService {
	List<Coupons> getAllCoupons() throws CouponException;
	List<Coupons> addCoupon(Coupons coupon) throws CouponException;
}
