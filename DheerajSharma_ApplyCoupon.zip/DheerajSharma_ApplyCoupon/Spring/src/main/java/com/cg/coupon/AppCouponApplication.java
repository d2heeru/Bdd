package com.cg.coupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppCouponApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppCouponApplication.class, args);
	}

}
