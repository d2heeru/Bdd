package com.cg.coupon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.coupon.bean.Coupons;
import com.cg.coupon.dao.CouponRepository;
import com.cg.coupon.exception.CouponException;
@Service
public class CouponServiceImpl implements CouponService{
	
	@Autowired
	private CouponRepository couponRepository;
	
	public List<Coupons> getAllCoupons() throws CouponException {
		
		try {
			return couponRepository.findAll();
		} catch (Exception e) {
			throw new CouponException(e.getMessage());
		}
	}

	public List<Coupons> addCoupon(Coupons coupon) throws CouponException {
		try {
			if(couponRepository.existsById(coupon.getCouponId()));
		} catch (Exception e) {
			throw new CouponException(e.getMessage());
		}
		couponRepository.save(coupon);
		return getAllCoupons();
	} 
	
}

