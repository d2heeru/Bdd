package com.cg.coupon.exception;

public class CouponException extends Exception{
	public CouponException() {
		super();
	}
	
	public CouponException(String msg) {
		super(msg);
	}

}
