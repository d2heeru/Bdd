package com.cg.registration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.registration.beans.RegistrationBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDef {
	
	private WebDriver driver;
	private RegistrationBean registrationBean; 
	
	private String htmlLocation = "file:///D:/Users/dheersha/Desktop/ConferenceRegistartion.html";
	
	@Before
	public void startUpSetup() {
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^User is on conference registration page$")
	public void user_is_on_conference_registration_page() throws Throwable {
		driver.get(htmlLocation);
		registrationBean = new RegistrationBean(driver);
	 
	}

	@Then("^Check whether heading is 'Conference Registration'$")
	public void check_whether_heading_is_Conference_Registration() throws Throwable {
		String actualHeading = registrationBean.getTitle();
		String expectedHeading = "Conference Registration";
		Assert.assertEquals(expectedHeading, actualHeading);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without entering first name$")
	public void user_click_on_next_button_without_entering_first_name() throws Throwable {
		registrationBean.setFirstName("");
		registrationBean.clicknxtBtn();
	}

	@Then("^Dispaly alert as 'Please fill the First Name'$")
	public void dispaly_alert_as_Please_fill_the_First_Name() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the First Name";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without entering Last name$")
	public void user_click_on_next_button_without_entering_Last_name() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("");
		registrationBean.clicknxtBtn();
	}

	@Then("^Dispaly alert as 'Please fill the Last Name'$")
	public void dispaly_alert_as_Please_fill_the_Last_Name() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Last Name";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without entering email$")
	public void user_click_on_next_button_without_entering_email() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("");
		registrationBean.clicknxtBtn();
	}

	@Then("^Dispaly alert as 'Please fill the Email'$")
	public void dispaly_alert_as_Please_fill_the_Email() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Email";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button  entering invalid email$")
	public void user_click_on_next_button_entering_invalid_email() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd");
		registrationBean.clicknxtBtn();
	}

	@Then("^Dispaly alert as 'Please enter valid Email Id'$")
	public void dispaly_alert_as_Please_enter_valid_Email_Id() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please enter valid Email Id";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without entering contact no$")
	public void user_click_on_next_button_without_entering_contact_no() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("");
		registrationBean.clicknxtBtn();
	}

	@Then("^Dispaly alert as 'Please fill the Contact No\\.'$")
	public void dispaly_alert_as_Please_fill_the_Contact_No() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Contact No.";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button  entering invalid contact no$")
	public void user_click_on_next_button_entering_invalid_contact_no() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("12");
		registrationBean.clicknxtBtn();
	}

	@Then("^Dispaly alert as 'Please enter valid Contact no\\.'$")
	public void dispaly_alert_as_Please_enter_valid_Contact_no() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Contact No.";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without selecting no of people$")
	public void user_click_on_next_button_without_selecting_no_of_people() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("7500959443");
		registrationBean.setNopeple("2");
		registrationBean.clicknxtBtn();
	}

	@Then("^Display alert as 'Please fill the Number of people attending'$")
	public void display_alert_as_Please_fill_the_Number_of_people_attending() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Number of people attending";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without entering building name and room no$")
	public void user_click_on_next_button_without_entering_building_name_and_room_no() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("7500959443");
		registrationBean.setNopeple("2");
		registrationBean.setAddress("");
		registrationBean.clicknxtBtn();
	}
	

	@Then("^Dispaly alert as 'Please fill the Building & Room No'$")
	public void dispaly_alert_as_Please_fill_the_Building_Room_No() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Building & Room No";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without entering area name$")
	public void user_click_on_next_button_without_entering_area_name() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("7500959443");
		registrationBean.setNopeple("2");
		registrationBean.setAddress("orion 402");
		registrationBean.clicknxtBtn();
	}

	@Then("^Dispaly alert as 'Please fill the Area name'$")
	public void dispaly_alert_as_Please_fill_the_Area_name() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Area name";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without selecting city$")
	public void user_click_on_next_button_without_selecting_city() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("7500959443");
		registrationBean.setNopeple("2");
		registrationBean.setAddress("orion 402");
		registrationBean.setCity("");
		registrationBean.clicknxtBtn();
	}

	@Then("^Display alert as 'Please select city'$")
	public void display_alert_as_Please_select_city() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please select city";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without selecting state$")
	public void user_click_on_next_button_without_selecting_state() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("7500959443");
		registrationBean.setNopeple("2");
		registrationBean.setAddress("orion 402");
		registrationBean.setCity("Pune");
		registrationBean.setState("");
		registrationBean.clicknxtBtn();
	}

	@Then("^Display alert as 'Please select state'$")
	public void display_alert_as_Please_select_state() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please select state";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on next button without selecting MemeberShip status$")
	public void user_click_on_next_button_without_selecting_MemeberShip_status() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("7500959443");
		registrationBean.setNopeple("2");
		registrationBean.setAddress("orion 402");
		registrationBean.setCity("Pune");
		registrationBean.setState("Tamilnadu");
		registrationBean.clicknxtBtn();
	}

	@Then("^Display alert as 'Please Select MemeberShip status'$")
	public void display_alert_as_Please_Select_MemeberShip_status() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please Select MemeberShip status";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters valid data and click next$")
	public void user_enters_valid_data_and_click_next() throws Throwable {
		registrationBean.setFirstName("Dheeraj");
		registrationBean.setLastName("Sharma");
		registrationBean.setEmail("abcd@gmail.com");
		registrationBean.setContactNo("7500959443");
		registrationBean.setNopeple("2");
		registrationBean.setAddress("orion 402");
		registrationBean.setArea("Mahindra");
		registrationBean.setCity("Pune");
		registrationBean.setState("Tamilnadu");
		registrationBean.setCheckBox();
		registrationBean.clicknxtBtn();
	}

	@Then("^Display 'Conference Details are validated\\.'$")
	public void display_Conference_Details_are_validated() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Conference Details are validated.";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}



}
