package com.cg.registration.beans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationBean {
	
	@SuppressWarnings("unused")
	private WebDriver driver;
	
	@FindBy(xpath = "/html/body/h2")
	@CacheLookup
	WebElement title;
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement contactNo;
	
	@FindBy(name="size")
	@CacheLookup
	WebElement nopeple;
	
	@FindBy(id="txtAddress1")
	@CacheLookup
	WebElement address;

	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement area;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[12]/td[2]/input")
	@CacheLookup
	WebElement checkBox;
	
	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement nextBtn;
	
	// Constructer to initialize elements
		public RegistrationBean(WebDriver driver) {
			super();
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}

		public String getTitle() {
			return title.getText();
		}

		public WebElement getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName.sendKeys(firstName);
		}

		public WebElement getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName.sendKeys(lastName);
		}

		public WebElement getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email.sendKeys(email);
		}

		public WebElement getContactNo() {
			return contactNo;
		}

		public void setContactNo(String contactNo) {
			this.contactNo.sendKeys(contactNo);
		}

		public WebElement getNopeple() {
			return nopeple;
		}

		public void setNopeple(String nopeple) {
			Select noSelect = new Select(this.nopeple);
			noSelect.selectByVisibleText(nopeple);
		}

		public WebElement getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address.sendKeys(address);
		}

		public WebElement getArea() {
			return area;
		}

		public void setArea(String area) {
			this.area.sendKeys(area);
		}

		public WebElement getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city.sendKeys(city);
		}

		public WebElement getState() {
			return state;
		}

		public void setState(String state) {
			this.state.sendKeys(state);
		}

		public WebElement getCheckBox() {
			return checkBox;
		}

		public void setCheckBox() {
			this.checkBox.click();
		}


		public void clicknxtBtn() {
			this.nextBtn.click();
		}
		
		

}
