package com.cg.registration.beans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentBean {
	@SuppressWarnings("unused")
	private WebDriver driver;
	
	@FindBy(xpath = "/html/body/form/h4")
	@CacheLookup
	WebElement title;

	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardHolderName;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement cardNo;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expMonth;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement expYear;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"btnPayment\"]")
	@CacheLookup
	WebElement makePayment;
	
	
	// Constructer to initialize elements
			public PaymentBean(WebDriver driver) {
				super();
				this.driver = driver;
				PageFactory.initElements(driver, this);
			}


			public String getTitle() {
				return title.getText();
			}

			public WebElement getCardHolderName() {
				return cardHolderName;
			}


			public void setCardHolderName(String cardHolderName) {
				this.cardHolderName.sendKeys(cardHolderName);
			}


			public WebElement getCardNo() {
				return cardNo;
			}


			public void setCardNo(String cardNo) {
				this.cardNo.sendKeys(cardNo);
			}


			public WebElement getCvv() {
				return cvv;
			}


			public void setCvv(String cvv) {
				this.cvv.sendKeys(cvv);
			}


			public WebElement getExpMonth() {
				return expMonth;
			}


			public void setExpMonth(String expMonth) {
				this.expMonth.sendKeys(expMonth);
			}


			public WebElement getExpYear() {
				return expYear;
			}


			public void setExpYear(String expYear) {
				this.expYear.sendKeys(expYear);
			}


			public void clickMakePayment() {
				this.makePayment.click();
			}
			
			
}
