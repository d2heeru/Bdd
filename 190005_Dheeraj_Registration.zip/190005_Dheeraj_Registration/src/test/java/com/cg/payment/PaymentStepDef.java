package com.cg.payment;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.registration.beans.PaymentBean;
import com.cg.registration.beans.RegistrationBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentStepDef {
	
	private WebDriver driver;
	private PaymentBean paymentBean; 
	
	private String htmlLocation = "file:///D:/Users/dheersha/Desktop/PaymentDetails.html";
	
	@Before
	public void startUpSetup() {
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^User is on payment details page$")
	public void user_is_on_payment_details_page() throws Throwable {
	    driver.get(htmlLocation);
	    paymentBean = new PaymentBean(driver);
	}

	@Then("^Check whether heading is 'Payment Details'$")
	public void check_whether_heading_is_Payment_Details() throws Throwable {
		String actualHeading = paymentBean.getTitle();
		String expectedHeading = "Debit card Details";
		Assert.assertEquals(expectedHeading, actualHeading);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on make payment button without entering card holder name$")
	public void user_click_on_make_payment_button_without_entering_card_holder_name() throws Throwable {
		paymentBean.setCardHolderName("");
		paymentBean.clickMakePayment();
	}

	@Then("^Dispaly alert as 'Please fill the Card holder name'$")
	public void dispaly_alert_as_Please_fill_the_Card_holder_name() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Card holder name";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on make payment button without entering Debit Card Number$")
	public void user_click_on_make_payment_button_without_entering_Debit_Card_Number() throws Throwable {
		paymentBean.setCardHolderName("Dheeraj Sharma");
		paymentBean.setCardNo("");
		paymentBean.clickMakePayment();
	}

	@Then("^Dispaly alert as 'Please fill the Debit card Number'$")
	public void dispaly_alert_as_Please_fill_the_Debit_card_Number() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Debit card Number";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on make payment button without entering cvv$")
	public void user_click_on_make_payment_button_without_entering_cvv() throws Throwable {
		paymentBean.setCardHolderName("Dheeraj Sharma");
		paymentBean.setCardNo("123456789");
		paymentBean.setCvv("");
		paymentBean.clickMakePayment();
	}

	@Then("^Dispaly alert as 'Please fill the CVV'$")
	public void dispaly_alert_as_Please_fill_the_CVV() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the CVV";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on make payment button without entering Expiration month$")
	public void user_click_on_make_payment_button_without_entering_Expiration_month() throws Throwable {
		paymentBean.setCardHolderName("Dheeraj Sharma");
		paymentBean.setCardNo("123456789");
		paymentBean.setCvv("123");
		paymentBean.setExpMonth("");
		paymentBean.clickMakePayment();
	}

	@Then("^Dispaly alert as 'Please fill expiration month'$")
	public void dispaly_alert_as_Please_fill_expiration_month() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill expiration month";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on make payment button without entering Expiration year$")
	public void user_click_on_make_payment_button_without_entering_Expiration_year() throws Throwable {
		paymentBean.setCardHolderName("Dheeraj Sharma");
		paymentBean.setCardNo("123456789");
		paymentBean.setCvv("123");
		paymentBean.setExpMonth("02");
		paymentBean.setExpYear("");
		paymentBean.clickMakePayment();
	    
	}

	@Then("^Dispaly alert as 'Please fill the expiration year'$")
	public void dispaly_alert_as_Please_fill_the_expiration_year() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the expiration year";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();

	}

	@When("^User enters valid data and click make payment button$")
	public void user_enters_valid_data_and_click_make_payment_button() throws Throwable {
		paymentBean.setCardHolderName("Dheeraj Sharma");
		paymentBean.setCardNo("123456789");
		paymentBean.setCvv("123");
		paymentBean.setExpMonth("02");
		paymentBean.setExpYear("1996");
		paymentBean.clickMakePayment();
	}

	@Then("^Display 'Conference Room Booking successfully done!!!'$")
	public void display_Conference_Room_Booking_successfully_done() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Conference Room Booking successfully done!!!";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}



}
