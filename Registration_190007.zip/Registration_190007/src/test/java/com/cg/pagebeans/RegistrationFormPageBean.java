package com.cg.pagebeans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationFormPageBean {
	/** Registration Page bean class to find elements and set the values */
	@SuppressWarnings("unused")
	private WebDriver driver;

	// Finding Elements
	@FindBy(xpath = "/html/body/h1")
	@CacheLookup
	WebElement heading;

	@FindBy(how = How.ID, using = "usrID")
	@CacheLookup
	WebElement userId;

	@FindBy(name = "passid")
	@CacheLookup
	WebElement password;

	@FindBy(xpath = "//*[@id=\"usrname\"]")
	@CacheLookup
	WebElement userName;

	@FindBy(xpath = "//*[@id=\"addr\"]")
	@CacheLookup
	WebElement address;

	@FindBy(name = "country")
	@CacheLookup
	WebElement country;

	@FindBy(how = How.NAME, using = "zip")
	@CacheLookup
	WebElement zipcode;

	@FindBy(how = How.XPATH, using = "/html/body/form/ul/li[14]/input")
	@CacheLookup
	WebElement email;

	@FindBy(xpath = "/html/body/form/ul/li[16]/input")
	@CacheLookup
	WebElement maleRadio;

	@FindBy(xpath = "/html/body/form/ul/li[17]/input")
	@CacheLookup
	WebElement femaleRadio;

	@FindBy(how = How.XPATH, using = "/html/body/form/ul/li[20]/input")
	@CacheLookup
	WebElement checkBox;

	@FindBy(how = How.XPATH, using = "/html/body/form/ul/li[23]/input")
	@CacheLookup
	WebElement submitBtn;

	// Constructer to initialize elements
	public RegistrationFormPageBean(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// setters and getters to get and set values
	public String getHeading() {
		return heading.getText();
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public void setCountry(String country) {
		Select countrySelect = new Select(this.country);
		countrySelect.selectByVisibleText(country);
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setMaleRadio() {
		this.maleRadio.click();
	}

	public void setFemaleRadio() {
		this.femaleRadio.click();
	}

	public void clickSubmitBtn() {
		this.submitBtn.click();
	}

	public void setCheckBox() {
		this.checkBox.click();
	}

}
