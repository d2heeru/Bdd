package com.cg.registration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

// Test runner class to run all scenarios
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features= {"src/test/resources/RegistrationForm"})
public class RegistrationForm_TestRunner {
	/** Test Runner class to run all test cases of registration form */
}
