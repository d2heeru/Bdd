package com.cg.registration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagebeans.RegistrationFormPageBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationFormStepDefinitions {

	/** Registration form step definition class which contains all the test case implementations */
	private WebDriver driver;
	private RegistrationFormPageBean registrationPageBean;
	// Relative path for HTML file 
	private String htmlLocation = "";

	// Setting the Driver Properties and getting the Chrome driver
	@Before
	public void startUpSetup() {
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}

	// Scenario test cases
	@Given("^User is on 'Registration Page'$")
	public void user_is_on_Registration_Page() throws Throwable {
		driver.get(htmlLocation);
		registrationPageBean = new RegistrationFormPageBean(driver);
	}

	@Then("^Check whether heading is 'Registration Form'$")
	public void check_whether_heading_is_Registration_Form() throws Throwable {
		String actualHeading = registrationPageBean.getHeading();
		String expectedHeading = "Registration Form";
		Assert.assertEquals(expectedHeading, actualHeading);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click submit entering invalid userid$")
	public void user_click_submit_entering_invalid_userid() throws Throwable {
		registrationPageBean.setUserId("SA1");
		registrationPageBean.clickSubmitBtn();
	}

	@Then("^Dispaly alert as 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
	public void dispaly_alert_as_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "User Id should not be empty / length be between 5 to 12";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click submit without entering userid$")
	public void user_click_submit_without_entering_userid() throws Throwable {
		registrationPageBean.setUserId("");
		registrationPageBean.clickSubmitBtn();
	}

	@When("^User click on submit entering invalid password$")
	public void user_click_on_submit_entering_invalid_password() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("123");
		registrationPageBean.clickSubmitBtn();
	}

	@Then("^Dispaly alert as 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	public void dispaly_alert_as_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2)
			throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Password should not be empty / length be between 7 to 12";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on submit without entering password$")
	public void user_click_on_submit_without_entering_password() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("");
		registrationPageBean.clickSubmitBtn();
	}

	@When("^User click on submit entering invalid name$")
	public void user_click_on_submit_entering_invalid_name() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriram123");
		registrationPageBean.clickSubmitBtn();
	}

	@Then("^Dispaly alert as 'Name should not be empty and must have alphabet characters only'$")
	public void dispaly_alert_as_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Name should not be empty and must have alphabet characters only";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on submit without entering  name$")
	public void user_click_on_submit_without_entering_name() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("");
		registrationPageBean.clickSubmitBtn();
	}

	@When("^User click on submit without entering address$")
	public void user_click_on_submit_without_entering_address() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("");
		registrationPageBean.clickSubmitBtn();
	}

	@Then("^Display alert as 'User address must have alphanumeric characters only'$")
	public void display_alert_as_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "User address must have alphanumeric characters only";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on submit entering invalid address$")
	public void user_click_on_submit_entering_invalid_address() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("Bno 272@1");
		registrationPageBean.clickSubmitBtn();
	}

	@When("^User click on submit without selecting country$")
	public void user_click_on_submit_without_selecting_country() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("housenumber272");
		registrationPageBean.clickSubmitBtn();

	}

	@Then("^Display alert as 'Select your country from the list'$")
	public void display_alert_as_Select_your_country_from_the_list() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Select your country from the list";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on submit without entering zipcode$")
	public void user_click_on_submit_without_entering_zipcode() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("housenumber272");
		registrationPageBean.setCountry("India");
		registrationPageBean.setZipcode("");
		registrationPageBean.clickSubmitBtn();
	}

	@Then("^Display alert as 'ZIP code must have numeric characters only'$")
	public void display_alert_as_ZIP_code_must_have_numeric_characters_only() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "ZIP code must have numeric characters only";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on submit entering invalid zipcode$")
	public void user_click_on_submit_entering_invalid_zipcode() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("housenumber272");
		registrationPageBean.setCountry("India");
		registrationPageBean.setZipcode("SADA");
		registrationPageBean.clickSubmitBtn();
	}

	@When("^User click on submit without entering email$")
	public void user_click_on_submit_without_entering_email() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("housenumber272");
		registrationPageBean.setCountry("India");
		registrationPageBean.setZipcode("603002");
		registrationPageBean.setEmail("");
		registrationPageBean.clickSubmitBtn();
	}

	@Then("^Display alert as 'You have entered an invalid email address!'$")
	public void display_alert_as_You_have_entered_an_invalid_email_address() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "You have entered an invalid email address!";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on submit entering invalid email$")
	public void user_click_on_submit_entering_invalid_email() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("housenumber272");
		registrationPageBean.setCountry("India");
		registrationPageBean.setZipcode("603002");
		registrationPageBean.setEmail("ram98.sri98");
		registrationPageBean.clickSubmitBtn();
	}

	@When("^User click on submit without selecting gender$")
	public void user_click_on_submit_without_selecting_gender() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("housenumber272");
		registrationPageBean.setCountry("India");
		registrationPageBean.setZipcode("603002");
		registrationPageBean.setEmail("ram98.sri98@gmail.com");
		registrationPageBean.clickSubmitBtn();

	}

	@Then("^Display alert as 'Please Select gender'$")
	public void display_alert_as_Please_Select_gender() throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please Select gender";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters valid information and click submit$")
	public void user_enters_valid_information_and_click_submit() throws Throwable {
		registrationPageBean.setUserId("SA123");
		registrationPageBean.setPassword("12345678");
		registrationPageBean.setUserName("Sriramprasad");
		registrationPageBean.setAddress("housenumber272");
		registrationPageBean.setCountry("India");
		registrationPageBean.setZipcode("603002");
		registrationPageBean.setEmail("ram98.sri98@gmail.com");
		registrationPageBean.setMaleRadio();
		registrationPageBean.setCheckBox();
		registrationPageBean.clickSubmitBtn();

	}

	@Then("^Display 'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile'$")
	public void display_Your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile()
			throws Throwable {
		String actualAlertMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		Assert.assertEquals(expectedMessage, actualAlertMessage);
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
}
